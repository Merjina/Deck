import React from "react";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, useStripe, useElements, CardElement } from "@stripe/react-stripe-js";
import axios from "axios";

const stripePromise = loadStripe("pk_test_51R3VesIW9dYCKtEBM5jSJbRTQtS0QNW39oxriypsZid5ylfygobTO3bi7fLPJI6v1I6uPItjhowowZzrCuE6kWMk00pHZHOcVb"); // Replace with your actual key

const CheckoutForm = ({ totalAmount }) => {
  const stripe = useStripe();
  const elements = useElements();

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!stripe || !elements) return;

    const { error, paymentMethod } = await stripe.createPaymentMethod({
      type: "card",
      card: elements.getElement(CardElement),
    });

    if (error) {
      console.error("Payment error:", error);
    } else {
      console.log("Payment successful!", paymentMethod);
      alert("Payment successful!!");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* ✅ Apply Custom Styling to CardElement */}
      <CardElement
        options={{
          style: {
            base: {
              color: "#ffffff", // White text
              backgroundColor: "#222222", // Dark background
              fontSize: "16px",
              "::placeholder": { color: "#bbbbbb" }, // Light gray placeholder
            },
            invalid: { color: "#ff4d4d" }, // Red text for errors
          },
        }}
        className="p-3 bg-dark rounded"
      />

      <button type="submit" disabled={!stripe} className="btn btn-success mt-3 w-100">
        Pay ${totalAmount.toFixed(2)}
      </button>
    </form>
  );
};

const PaymentButton = ({ totalAmount }) => (
  <Elements stripe={stripePromise}>
    <CheckoutForm totalAmount={totalAmount} />
  </Elements>
);

export default PaymentButton;
