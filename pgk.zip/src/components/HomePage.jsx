import React from "react";
import { motion } from "framer-motion";
import Button from "./ui/Button";
import Navbar from "./Navbar";

export default function HomePage() {
  return (
    <div className="w-full min-h-screen bg-gray-100">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative w-full h-screen flex items-center justify-center text-center bg-cover bg-center" style={{ backgroundImage: "url('https://source.unsplash.com/featured/?interior,design')" }}>
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 1 }} 
          className="relative z-10 text-white max-w-2xl p-6">
          <h1 className="text-5xl font-bold">Transform Your Space</h1>
          <p className="mt-4 text-lg">Elevate your interiors with our expert designs.</p>
          <Button className="mt-6 bg-white text-black px-6 py-3 rounded-xl shadow-lg hover:bg-gray-200">Get Started</Button>
        </motion.div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-6 text-center">
        <h2 className="text-3xl font-semibold">Our Services</h2>
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          {['Modern Designs', 'Space Planning', 'Custom Furniture'].map((service, index) => (
            <motion.div 
              key={index} 
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ delay: index * 0.2 }} 
              className="p-6 bg-white shadow-lg rounded-xl">
              <h3 className="text-xl font-bold">{service}</h3>
              <p className="mt-2 text-gray-600">We craft beautiful interiors tailored to your style.</p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
