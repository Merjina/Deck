/*Navbar*/
import React from 'react'
import "../styles/NavBar.css";
import SearchBar from './SearchBar';


function Navbar() {
  return (
    <div>
        <nav className="login-navbar">
    
    <ul className="login-navbar-links">
    <li className="login-navbar-logo">Deckline</li>
      <li><a href="/home">Home</a></li>
      <li><a href="#products">Products</a></li>
      <li><a href="#contact">Contact</a></li>
      <SearchBar/>
     <li className='nav-icon'><a href="#"><i className=" nav-icon bi bi-cart4"></i></a></li>
     <li className='nav-icon'><a href="#"><i class="bi bi-bag-heart-fill"></i></a></li>
     <li className='nav-icon'><a href="#"><i class="bi bi-person-circle"></i></a></li>
    </ul>
  </nav>
  </div>
  )
}

export default Navbar