import React from 'react'
import "../styles/NavBar.css";
import SearchBar from './SearchBar';


function Navbar() {
  return (
    <div>
        <nav className="login-navbar">
    
    <ul className="login-navbar-links">
    <li className="login-navbar-logo">Deckline</li>
      <li><a href="/home">Add products</a></li>
      <li><a href="#products">Inventory</a></li>
      <li><a href="#contact">Quotation Requests</a></li>
      <SearchBar/>
     
     <li className='nav-icon'><a href="#"><i class="bi bi-person-circle"></i></a></li>
    </ul>
  </nav>
  </div>
  )
}

export default Navbar