import axios from "axios"; 
 
const BASE_URL = "http://localhost:8080/api/auth"; // Your backend URL 
 
export const registerUser = async (userData) => { 
  try { 
    const response = await axios.post(`${BASE_URL}/signup`, userData, { 
      headers: { "Content-Type": "application/json" }, 
    }); 
 
    // Log the response to ensure it's in the correct format 
    console.log(response.data); // It should return { message: "User registered successfully!" } 
 
    return response.data; // Should return { message: "User registered successfully!" } 
  } catch (error) { 
    console.error(error); 
 
    // If there's an error, show the error message from the response 
    throw error.response ? error.response.data.message : "Error signing up!"; 
  } 
   
}; 
export const loginUser = async (loginData) => { 
    try { 
      const response = await axios.post(`${BASE_URL}/login`, loginData, { 
        headers: { "Content-Type": "application/json" }, 
      }); 
   
      console.log(response.data); // You should log or inspect the response to ensure it's correct 
      return response.data; // Returns { message: "Login successful!" } 
    } catch (error) { 
      console.error(error); 
   
      // If error, return a user-friendly message 
      throw error.response ? error.response.data.message : "Error logging in!"; 
    } 
  };