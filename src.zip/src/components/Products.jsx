import React, { useEffect, useState } from "react";
import axios from "axios";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { FaHeart } from "react-icons/fa";
import { Link } from "react-router-dom"; // Import Link for navigation
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/Products.css";
import Navbar from "./Navbar";
import Footer from "./Footer";

const Products = () => {
  const [products, setProducts] = useState([]);
  const [wishlist, setWishlist] = useState([]);

  // Fetch products and wishlist
  useEffect(() => {
    // Fetch products
    axios.get("http://localhost:8081/api/products")
      .then(response => setProducts(response.data))
      .catch(error => console.error("Error fetching products:", error));

    // Fetch wishlist
    fetchWishlist();
  }, []);

  // Fetch wishlist data (user-specific)
  const fetchWishlist = () => {
    const token = localStorage.getItem("token");  // Retrieve token from localStorage

    if (!token) {
      console.log("No token found. Please login.");
      return;
    }

    axios.get("http://localhost:8081/api/wishlist", {
      headers: {
        "Authorization": `Bearer ${token}`  // Include the token in the request headers
      }
    })
    .then(response => setWishlist(response.data))
    .catch(error => console.error("Error fetching wishlist:", error));
  };

  // Add product to the cart (user-specific)
  const addToCart = (product) => {
    const token = localStorage.getItem("token");  // Retrieve token from localStorage

    if (!token) {
      console.log("No token found. Please login.");
      return;
    }

    const cartItem = {
      productId: Number(product.id),
      name: product.name,
      imagePath: product.imagePath,
      price: product.price,
      quantity: 1
    };

    axios.post("http://localhost:8081/api/cart/add", cartItem, {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`  // Include the token in the request headers
      }
    })
    .then(() => {
      window.alert(`${product.name} added to cart! 🛒`);
    })
    .catch(error => {
      if (error.response && error.response.status === 409) {
        window.alert(`${product.name} is already in the cart! ⚠️`);
      } else {
        console.error("Error adding to cart:", error);
        window.alert("Something went wrong while adding to cart! 😓");
      }
    });
  };

  // Add product to the wishlist (user-specific)
  const addToWishlist = (product) => {
    const token = localStorage.getItem("token");  // Retrieve token from localStorage

    if (!token) {
      console.log("No token found. Please login.");
      return;
    }

    axios.post("http://localhost:8081/api/wishlist/add", {
      productId: product.id,
      name: product.name,
      imagePath: product.imagePath,
      price: product.price
    }, {
      headers: {
        "Authorization": `Bearer ${token}`  // Include the token in the request headers
      }
    })
    .then(() => {
      fetchWishlist();  // Refresh wishlist after adding
      window.alert(`${product.name} added to wishlist! ❤️`);
    })
    .catch(error => {
      if (error.response && error.response.status === 409) {
        window.alert(`${product.name} is already in the wishlist! 📝`);
      } else {
        console.error("Error adding to wishlist", error);
        window.alert("Something went wrong while adding to wishlist! 😬");
      }
    });
  };

  return (
    <>
      <Navbar />
      <Container className="text-center my-5">
        <h2 className="text-light">Our Products</h2>
        <Row className="mt-4">
          {products.map((product) => (
            <Col md={4} key={product.id} className="mb-4">
              <Card className="bg-dark text-light product-card">
                {/* Clicking on the image or title navigates to the product details page */}
                <Link to={`/product/${product.id}`} className="text-decoration-none">
                  <Card.Img 
                    variant="top" 
                    src={`http://localhost:8081/api/products/images/${product.imagePath}`} 
                    onError={(e) => e.target.src = "placeholder.jpg"} 
                    className="product-image"
                  />
                  <Card.Body>
                    <Card.Title className="text-warning">{product.name}</Card.Title>
                  </Card.Body>
                </Link>
                <Card.Body>
                  <Card.Text>{product.description}</Card.Text>
                  <h5 className="text-light">₹{product.price}</h5>
                  <div className="d-flex justify-content-between">
                    <Button variant="warning" onClick={() => addToCart(product)}>
                      Add to Cart
                    </Button>
                    <FaHeart
                      size={24}
                      color={wishlist.some(item => item.productId === product.id) ? "red" : "white"}
                      style={{ cursor: "pointer" }}
                      onClick={() => addToWishlist(product)}
                    />
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
      <Footer />
    </>
  );
};

export default Products;
