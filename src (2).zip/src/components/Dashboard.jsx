import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/Dashboard.css";

const Dashboard = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrders(); // Fetch orders when the component loads

    // ✅ Set up live updates every 5 seconds
    const interval = setInterval(() => {
      fetchOrders();
    }, 5000); // 5000ms = 5 seconds

    return () => clearInterval(interval); // Cleanup interval on unmount
  }, []);

  const fetchOrders = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/orders");
      setOrders(response.data.reverse().slice(0, 5)); // Show only latest 5 orders
    } catch (error) {
      console.error("Error fetching orders:", error);
    }
  };

  return (
    <div className="dashboard-container">
      <h2 className="dashboard-title">Admin Dashboard</h2>

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <h3>Total Sales</h3>
          <p>₹2,50,000</p>
        </div>
        <div className="stat-card">
          <h3>Pending Orders</h3>
          <p>12</p>
        </div>
        <div className="stat-card">
          <h3>New Quotations</h3>
          <p>8</p>
        </div>
        <div className="stat-card">
          <h3>Total Customers</h3>
          <p>540</p>
        </div>
      </div>

      {/* Recent Activity Log */}
      <div className="dashboard-section">
        <h3>Recent Activity</h3>
        <ul className="activity-list">
          <li>🟢 New order placed by John Doe (₹5,500)</li>
          <li>🔵 Admin approved a quotation request</li>
          <li>🟠 2 orders are pending for shipment</li>
          <li>🟢 Customer Jane Smith registered an account</li>
        </ul>
      </div>

      {/* ✅ Latest Orders Table with Live Updates */}
      <div className="dashboard-section">
        <h3>Latest Orders</h3>
        <table>
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Customer</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
  {orders.length === 0 ? (
    <tr>
      <td colSpan="4" className="text-center">No recent orders.</td>
    </tr>
  ) : (
    orders.map((order) => (
      <tr key={order.id}>
        <td>#{order.id}</td>
        <td>{order.customerName}</td>
        <td>₹{order.totalAmount.toFixed(2)}</td>
        <td>Processing</td> {/* Ensure there is no extra space here */}
      </tr>
    ))
  )}
</tbody>

        </table>
      </div>

      {/* Placeholder for future widgets */}
      <div className="dashboard-section">
        <h3>Performance Overview</h3>
        <div className="chart-placeholder">
          <p>📊 Chart Placeholder (Future Data Visualizations)</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
