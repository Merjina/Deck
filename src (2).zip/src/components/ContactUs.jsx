// import React from "react";
// import { Container, Row, Col, Form, Button } from "react-bootstrap";
// import "bootstrap/dist/css/bootstrap.min.css";
// import "../styles/ContactUs.css"; // Custom CSS
// import Navbar from "./Navbar";
// import Footer from "./Footer";

// const ContactUs = () => {
//   return (
//     <>
//       <Navbar />

//       {/* Hero Section */}
//       <section className="contact-hero text-center">
//         <Container>
//           <h1 className="text-light">Contact <span className="text-warning">Us</span></h1>
//           <p className="lead text-light">We’d love to hear from you! Get in touch with us.</p>
//         </Container>
//       </section>

//       {/* Contact Info & Form */}
//       <Container className="my-5">
//         <Row>
//           {/* Contact Details */}
//           <Col md={5} className="contact-info">
//             <h2 className="text-warning">Get in Touch</h2>
//             <p><strong>📍 Address:</strong> 123 Interior Design Street, City</p>
//             <p><strong>📞 Phone:</strong> +123 456 7890</p>
//             <p><strong>📧 Email:</strong> contact@deckline.com</p>
//             <p><strong>🕒 Business Hours:</strong> Mon-Fri, 9 AM - 6 PM</p>
//           </Col>

//           {/* Contact Form */}
//           <Col md={7}>
//             <h2 className="text-warning">Send Us a Message</h2>
//             <Form>
//               <Form.Group className="mb-3">
//                 <Form.Label>Name</Form.Label>
//                 <Form.Control type="text" placeholder="Enter your name" required />
//               </Form.Group>
//               <Form.Group className="mb-3">
//                 <Form.Label>Email</Form.Label>
//                 <Form.Control type="email" placeholder="Enter your email" required />
//               </Form.Group>
//               <Form.Group className="mb-3">
//                 <Form.Label>Subject</Form.Label>
//                 <Form.Control type="text" placeholder="Enter subject" required />
//               </Form.Group>
//               <Form.Group className="mb-3">
//                 <Form.Label>Message</Form.Label>
//                 <Form.Control as="textarea" rows={4} placeholder="Write your message" required />
//               </Form.Group>
//               <Button variant="warning" type="submit">Send Message</Button>
//             </Form>
//           </Col>
//         </Row>
//       </Container>

//       <Footer />
//     </>
//   );
// };

// export default ContactUs;
// import React from "react";
// import { Container, Row, Col, Form, Button } from "react-bootstrap";
// import "bootstrap/dist/css/bootstrap.min.css";
// import "../styles/ContactUs.css"; // Custom CSS
// import Navbar from "./Navbar";
// import Footer from "./Footer";
// import contactImage from "../assets/images/about-bg.jpg"; // Import the image

// const ContactUs = () => {
//   return (
//     <>
//       <Navbar />

//       {/* Contact Image Section */}
//       <section className="contact-image-section">
//         <img src={contactImage} alt="Contact Us" className="contact-image" />
//       </section>

//       {/* Contact Info & Form */}
//       <Container className="my-5">
//         <Row>
//           {/* Contact Details */}
//           <Col md={5} className="contact-info">
// //             <h2 className="text-warning">Get in Touch</h2>
// //             <p><strong>📍 Address:</strong> 123 Interior Design Street, City</p>
// //             <p><strong>📞 Phone:</strong> +123 456 7890</p>
// //             <p><strong>📧 Email:</strong> contact@deckline.com</p>
// //             <p><strong>🕒 Business Hours:</strong> Mon-Fri, 9 AM - 6 PM</p>
// //           </Col>

//           {/* Contact Form */}
//           <Col md={7}>
//             <div className="contact-form-box">
//               <h2 className="text-warning text-center">Send Us a Message</h2>
//               <Form>
//                 <Form.Group className="mb-3">
//                   <Form.Label>Name</Form.Label>
//                   <Form.Control type="text" placeholder="Enter your name" required />
//                 </Form.Group>
//                 <Form.Group className="mb-3">
//                   <Form.Label>Email</Form.Label>
//                   <Form.Control type="email" placeholder="Enter your email" required />
//                 </Form.Group>
//                 <Form.Group className="mb-3">
//                   <Form.Label>Subject</Form.Label>
//                   <Form.Control type="text" placeholder="Enter subject" required />
//                 </Form.Group>
//                 <Form.Group className="mb-3">
//                   <Form.Label>Message</Form.Label>
//                   <Form.Control as="textarea" rows={4} placeholder="Write your message" required />
//                 </Form.Group>
//                 <div className="text-center">
//                   <Button variant="warning" type="submit">Send Message</Button>
//                 </div>
//               </Form>
//             </div>
//           </Col>
//         </Row>
//       </Container>

//       <Footer />
//     </>
//   );
// };

// export default ContactUs;

import React from "react";
import { Container, Row, Col, Form, Button, Card } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/ContactUs.css"; // Custom CSS
import Navbar from "./Navbar";
import Footer from "./Footer";
import contactImage from "../assets/images/about-bg.jpg"; // Import the image

const ContactUs = () => {
  return (
    <>
      <Navbar />

      {/* Hero Section */}
      <section className="hero-section text-center">
        <Container>
          <h1 className="text-light">
            Contact <span className="text-warning">Us</span>
          </h1>
          <p className="lead text-light">
            Have questions? We’re here to help. Reach out to us today!
          </p>
        </Container>
      </section>

      {/* Contact Info & Form */}
      <Container className="my-5">
        <Row className="align-items-center">
          <Col md={5}>
            <Card className="contact-info bg-dark text-light">
              <Card.Body>
                <Card.Title className="text-warning">Get in Touch</Card.Title>
                <Card.Text>
                  <strong>📍 Address:</strong> 123 Interior Design Street, City
                </Card.Text>
                <Card.Text>
                  <strong>📞 Phone:</strong> +123 456 7890
                </Card.Text>
                <Card.Text>
                  <strong>📧 Email:</strong> contact@deckline.com
                </Card.Text>
                <Card.Text>
                  <strong>🕒 Business Hours:</strong> Mon-Fri, 9 AM - 6 PM
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>

          {/* Contact Form */}
          <Col md={6}>
            <div className="contact-form-box">
              <h2 className="text-warning text-center">Send Us a Message</h2>
              <Form>
                <Form.Group className="mb-3">
                  <Form.Label>Name</Form.Label>
                  <Form.Control type="text" placeholder="Enter your name" required />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Email</Form.Label>
                  <Form.Control type="email" placeholder="Enter your email" required />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Subject</Form.Label>
                  <Form.Control type="text" placeholder="Enter subject" required />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Message</Form.Label>
                  <Form.Control as="textarea" rows={4} placeholder="Write your message" required />
                </Form.Group>
                <div className="text-center">
                  <Button variant="warning" type="submit">Send Message</Button>
                </div>
              </Form>
            </div>
          </Col>
        </Row>
      </Container>

      {/* Call to Action */}
      <section className="cta-section text-center py-5">
        <Container>
          <h2 className="text-light">Let's Work Together</h2>
          <p className="lead text-light">
            We’re excited to help you with your design needs. Get in touch today!
          </p>
          <Button variant="warning" size="lg">Get in Touch</Button>
        </Container>
      </section>

      <Footer />
    </>
  );
};

export default ContactUs;
