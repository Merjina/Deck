import React, { useState } from "react";
import { Navbar, Nav, Container, Form, FormControl, Button, ListGroup, ListGroupItem } from "react-bootstrap";
import { FaSearch, FaHeart, FaShoppingCart, FaSignOutAlt } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import logo from "../assets/images/decklineLogo.png";
import axios from "axios";
import "../styles/NavBar.css";

const Navbar1 = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState(""); // To store the search query
  const [searchResults, setSearchResults] = useState([]); // To store the search results

  const handleLogout = () => {
    const confirmLogout = window.confirm("Are you sure you want to logout?");
    if (confirmLogout) {
      localStorage.removeItem("token"); // Remove authentication token
      navigate("/", { replace: true }); // Redirect to login page after logout
    }
  };



  return (
    <Navbar variant="dark" expand="lg" className="px-3">
      <Container fluid>
        <Navbar.Brand href="/">
          <img src={logo} alt="Logo" width="150" height="60" className="d-inline-block align-top" />
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="navbar-nav" />
        <Navbar.Collapse id="navbar-nav" className="justify-content-between">
          <Nav className="mx-auto ml-5">
            <Nav.Link href="/home">Home</Nav.Link>
            <Nav.Link href="/products">Products</Nav.Link>
            <Nav.Link href="/about-us">About</Nav.Link>
            <Nav.Link href="/contact-us">Contact Us</Nav.Link>
            <Nav.Link href="/profile">Profile</Nav.Link>
            <Nav.Link href="/my_quotations">My Quotations</Nav.Link>
          </Nav>

          <Nav className="right-end">
            


            <Nav.Link href="/wishlist">
              <FaHeart />
            </Nav.Link>
            <Nav.Link href="/cart">
              <FaShoppingCart />
            </Nav.Link>
            <Nav.Link onClick={handleLogout} style={{ cursor: "pointer" }}>
              <FaSignOutAlt title="Logout" />
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Navbar1;
